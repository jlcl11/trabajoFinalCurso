package enums;

public enum Posicion {
	BASE,ESCOLTA,ALERO,ALAPIVOT,PIVOT
}
