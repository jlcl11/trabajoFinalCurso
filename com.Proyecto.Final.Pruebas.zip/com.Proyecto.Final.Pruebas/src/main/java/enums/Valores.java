package enums;

public enum Valores {
	A,B,C,D
}
