package exceptions;

public class EquipoMalIntroduciodoException extends Exception{

	public EquipoMalIntroduciodoException(String msg) {
		super(msg);
	}
}
